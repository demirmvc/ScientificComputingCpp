docker run --rm -it --mount type=bind,source=$PWD,target=/home/dev/mnt psaberi/hpc
