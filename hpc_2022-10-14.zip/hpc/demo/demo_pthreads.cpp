#include <iostream>
#include <sstream>
#include <vector>
#include <stdlib.h>
#include <pthread.h>

void *start_routine(void *arg)
{
  int tid = *(int *)arg;

  std::stringstream ss;
  ss << "Thread " << tid << " : Hello world!\n";
  std::cout << ss.str();

  pthread_exit(NULL);
}

int main(int argc, char **argv)
{
  pthread_t threadId1;
  int tid1 = 1;
  pthread_create(&threadId1, NULL, start_routine, &tid1);

  pthread_t threadId2;
  int tid2 = 2;
  pthread_create(&threadId2, NULL, start_routine, &tid2);

  pthread_exit(NULL);
}