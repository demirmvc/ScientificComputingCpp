#include <omp.h>
#include <stdio.h>

int main()
{

#pragma omp parallel
  {
    int tid = omp_get_thread_num();
    printf("Hello World from thread = %d\n", tid);

#pragma omp master
    {
      int nThreads = omp_get_num_threads();
      printf("****** Number of threads = %d *****\n", nThreads);
    }
  }
  return 0;
}