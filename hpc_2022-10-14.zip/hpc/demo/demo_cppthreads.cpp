#include <string>
#include <iostream>
#include <thread>
using namespace std;

void helloWorld() { cout << "Hello World\n"; }

int main()
{
  thread thread1(helloWorld);
  thread thread2(helloWorld);
  thread1.join();
  thread2.join();
}